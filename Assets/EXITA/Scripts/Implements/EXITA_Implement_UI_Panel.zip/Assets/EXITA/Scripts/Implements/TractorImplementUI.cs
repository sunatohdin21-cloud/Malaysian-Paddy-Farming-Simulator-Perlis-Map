using UnityEngine;
using UnityEngine.UI;

namespace ExitaUtara
{
    /// <summary>
    /// Connect this to the on-screen tractor implement panel.
    /// Uses Unity's built-in UI Text and Button components (no TMP package required).
    /// </summary>
    public class TractorImplementUI : MonoBehaviour
    {
        [Header("System")]
        [SerializeField] private TractorImplementSystem tractorSystem;

        [Header("Buttons")]
        [SerializeField] private Button attachButton;
        [SerializeField] private Button detachButton;
        [SerializeField] private Button liftButton;
        [SerializeField] private Button ptoButton;

        [Header("Labels")]
        [SerializeField] private Text implementNameText;
        [SerializeField] private Text attachButtonText;
        [SerializeField] private Text liftButtonText;
        [SerializeField] private Text ptoButtonText;
        [SerializeField] private Text hintText;

        private void OnEnable()
        {
            if (attachButton != null) attachButton.onClick.AddListener(OnAttach);
            if (detachButton != null) detachButton.onClick.AddListener(OnDetach);
            if (liftButton != null) liftButton.onClick.AddListener(OnLift);
            if (ptoButton != null) ptoButton.onClick.AddListener(OnPto);
            Refresh();
        }

        private void OnDisable()
        {
            if (attachButton != null) attachButton.onClick.RemoveListener(OnAttach);
            if (detachButton != null) detachButton.onClick.RemoveListener(OnDetach);
            if (liftButton != null) liftButton.onClick.RemoveListener(OnLift);
            if (ptoButton != null) ptoButton.onClick.RemoveListener(OnPto);
        }

        private void Update()
        {
            Refresh();
        }

        public void OnAttach()
        {
            if (tractorSystem == null) return;
            bool success = tractorSystem.TryAttachNearby();
            if (hintText != null)
                hintText.text = success ? "Peralatan berjaya dipasang." :
                    "Tiada peralatan sesuai berhampiran hitch.";
            Refresh();
        }

        public void OnDetach()
        {
            if (tractorSystem == null) return;
            if (!tractorSystem.HasImplement)
            {
                if (hintText != null) hintText.text = "Tiada peralatan untuk ditanggalkan.";
                return;
            }
            tractorSystem.Detach();
            if (hintText != null) hintText.text = "Peralatan ditanggalkan.";
            Refresh();
        }

        public void OnLift()
        {
            if (tractorSystem == null || !tractorSystem.HasImplement)
            {
                if (hintText != null) hintText.text = "Pasang peralatan dahulu.";
                return;
            }
            tractorSystem.ToggleImplementLift();
            Refresh();
        }

        public void OnPto()
        {
            if (tractorSystem == null || !tractorSystem.HasImplement)
            {
                if (hintText != null) hintText.text = "Pasang peralatan dahulu.";
                return;
            }
            tractorSystem.TogglePto();
            if (hintText != null)
                hintText.text = tractorSystem.IsPtoOn ? "PTO dihidupkan." : "PTO dimatikan / tidak diperlukan.";
            Refresh();
        }

        public void Refresh()
        {
            if (tractorSystem == null) return;

            bool has = tractorSystem.HasImplement;
            FarmImplement current = tractorSystem.AttachedImplement;

            if (implementNameText != null)
                implementNameText.text = has ? current.Type.ToString() : "Tiada peralatan";

            if (attachButton != null) attachButton.interactable = !has;
            if (detachButton != null) detachButton.interactable = has;
            if (liftButton != null) liftButton.interactable = has;
            if (ptoButton != null)
                ptoButton.interactable = has && current.RequiresPto;

            if (attachButtonText != null) attachButtonText.text = "PASANG";
            if (liftButtonText != null)
                liftButtonText.text = tractorSystem.IsImplementRaised ? "TURUNKAN" : "ANGKAT";
            if (ptoButtonText != null)
                ptoButtonText.text = tractorSystem.IsPtoOn ? "PTO OFF" : "PTO ON";

            if (hintText != null && !has)
                hintText.text = "Undur traktor ke peralatan dan tekan PASANG.";
        }
    }
}
