using UnityEngine;

namespace ExitaUtara
{
    /// <summary>
    /// Add to the root of Ford 366 and Ford 5000.
    /// Mobile UI buttons can call the public methods directly.
    /// </summary>
    public class TractorImplementSystem : MonoBehaviour
    {
        [Header("Hitch references")]
        [SerializeField] private Transform hitchPoint;
        [SerializeField] private Transform implementParent;
        [SerializeField] private Transform leftLowerLink;
        [SerializeField] private Transform rightLowerLink;
        [SerializeField] private Transform topLink;

        [Header("Hitch animation")]
        [SerializeField] private Vector3 linksRaisedEuler = new Vector3(-18f, 0f, 0f);
        [SerializeField] private Vector3 linksLoweredEuler = Vector3.zero;
        [SerializeField, Min(0.1f)] private float linkMoveSpeed = 35f;

        [Header("Attachment")]
        [SerializeField, Min(0.1f)] private float attachDistance = 2.5f;
        [SerializeField] private FarmImplement nearbyImplement;

        [Header("Runtime (read only)")]
        [SerializeField] private FarmImplement attachedImplement;
        [SerializeField] private bool ptoOn;
        [SerializeField] private bool implementRaised;

        private Quaternion leftRaised, leftLowered, rightRaised, rightLowered;
        private Quaternion topRaised, topLowered;

        public FarmImplement AttachedImplement => attachedImplement;
        public bool HasImplement => attachedImplement != null;
        public bool IsPtoOn => ptoOn;
        public bool IsImplementRaised => implementRaised;

        private void Awake()
        {
            if (implementParent == null) implementParent = transform;
            leftRaised = Quaternion.Euler(linksRaisedEuler);
            leftLowered = Quaternion.Euler(linksLoweredEuler);
            rightRaised = Quaternion.Euler(linksRaisedEuler);
            rightLowered = Quaternion.Euler(linksLoweredEuler);
            topRaised = Quaternion.Euler(linksRaisedEuler);
            topLowered = Quaternion.Euler(linksLoweredEuler);
        }

        private void Update()
        {
            AnimateLink(leftLowerLink, implementRaised ? leftRaised : leftLowered);
            AnimateLink(rightLowerLink, implementRaised ? rightRaised : rightLowered);
            AnimateLink(topLink, implementRaised ? topRaised : topLowered);
        }

        private void AnimateLink(Transform link, Quaternion target)
        {
            if (link == null) return;
            link.localRotation = Quaternion.RotateTowards(
                link.localRotation, target, linkMoveSpeed * Time.deltaTime);
        }

        /// <summary>Called by a trigger/helper or a mobile UI selection.</summary>
        public void SetNearbyImplement(FarmImplement implement)
        {
            nearbyImplement = implement;
        }

        public bool TryAttachNearby()
        {
            if (attachedImplement != null || nearbyImplement == null || hitchPoint == null)
                return false;

            if (Vector3.Distance(hitchPoint.position, nearbyImplement.transform.position) > attachDistance)
                return false;

            Attach(nearbyImplement);
            return true;
        }

        public void Attach(FarmImplement implement)
        {
            if (implement == null || attachedImplement != null || hitchPoint == null)
                return;

            Transform targetParent = implementParent != null ? implementParent : transform;
            Transform implementTransform = implement.transform;

            // Align implement-side attach point to the tractor hitch before parenting.
            if (implement.AttachPoint != null)
            {
                Quaternion rotationOffset = hitchPoint.rotation * Quaternion.Inverse(implement.AttachPoint.rotation);
                implementTransform.rotation = rotationOffset * implementTransform.rotation;
                Vector3 positionOffset = hitchPoint.position - implement.AttachPoint.position;
                implementTransform.position += positionOffset;
            }
            else
            {
                implementTransform.SetPositionAndRotation(hitchPoint.position, hitchPoint.rotation);
            }

            implementTransform.SetParent(targetParent, true);
            attachedImplement = implement;
            attachedImplement.SetAttached(true);
            nearbyImplement = null;
            SetPto(false);
            SetImplementRaised(false);
        }

        public void Detach()
        {
            if (attachedImplement == null) return;

            SetPto(false);
            attachedImplement.SetAttached(false);
            attachedImplement.transform.SetParent(null, true);
            attachedImplement = null;
            implementRaised = false;
        }

        public void TogglePto()
        {
            SetPto(!ptoOn);
        }

        public void SetPto(bool value)
        {
            ptoOn = value && attachedImplement != null && attachedImplement.RequiresPto;
            if (attachedImplement != null)
                attachedImplement.SetPto(ptoOn);
        }

        public void ToggleImplementLift()
        {
            SetImplementRaised(!implementRaised);
        }

        public void SetImplementRaised(bool value)
        {
            implementRaised = value && attachedImplement != null;
            if (attachedImplement != null)
                attachedImplement.SetRaised(implementRaised);
        }

        // Convenience methods for Unity UI Button OnClick bindings.
        public void UI_Attach() => TryAttachNearby();
        public void UI_Detach() => Detach();
        public void UI_TogglePto() => TogglePto();
        public void UI_RaiseLower() => ToggleImplementLift();
    }
}
