using UnityEngine;

namespace ExitaUtara
{
    public enum FarmImplementType
    {
        Rotavator,
        Plough,
        Puddler,
        LandLeveller,
        Trailer,
        FertilizerSpreader,
        Sprayer,
        RiceTransplanter,
        WaterPump,
        Other
    }

    /// <summary>
    /// Attach this component to the ROOT GameObject of each implement prefab/model.
    /// The attachPoint is the implement-side hitch reference.
    /// </summary>
    public class FarmImplement : MonoBehaviour
    {
        [Header("Implement")]
        [SerializeField] private FarmImplementType implementType = FarmImplementType.Other;
        [SerializeField] private Transform attachPoint;
        [SerializeField] private bool requiresPto;
        [SerializeField] private Transform liftPivot;
        [SerializeField] private Vector3 loweredLocalEuler;
        [SerializeField] private Vector3 raisedLocalEuler = new Vector3(-25f, 0f, 0f);
        [SerializeField, Min(0.1f)] private float liftSpeed = 45f;

        [Header("Runtime (read only)")]
        [SerializeField] private bool attached;
        [SerializeField] private bool ptoRunning;

        private Quaternion loweredRotation;
        private Quaternion raisedRotation;
        private bool isRaised;

        public FarmImplementType Type => implementType;
        public Transform AttachPoint => attachPoint;
        public bool RequiresPto => requiresPto;
        public bool IsAttached => attached;
        public bool IsPtoRunning => ptoRunning;
        public bool IsRaised => isRaised;

        private void Awake()
        {
            if (liftPivot != null)
            {
                loweredRotation = Quaternion.Euler(loweredLocalEuler);
                raisedRotation = Quaternion.Euler(raisedLocalEuler);
            }
        }

        private void Update()
        {
            if (liftPivot == null) return;

            Quaternion target = isRaised ? raisedRotation : loweredRotation;
            liftPivot.localRotation = Quaternion.RotateTowards(
                liftPivot.localRotation, target, liftSpeed * Time.deltaTime);
        }

        public void SetAttached(bool value)
        {
            attached = value;
            if (!value) SetPto(false);
        }

        public void SetRaised(bool value)
        {
            isRaised = value;
        }

        public void SetPto(bool value)
        {
            ptoRunning = value && attached && requiresPto;
            ImplementPtoRotor[] rotors = GetComponentsInChildren<ImplementPtoRotor>(true);
            foreach (ImplementPtoRotor rotor in rotors)
                rotor.SetRunning(ptoRunning);
        }
    }
}
