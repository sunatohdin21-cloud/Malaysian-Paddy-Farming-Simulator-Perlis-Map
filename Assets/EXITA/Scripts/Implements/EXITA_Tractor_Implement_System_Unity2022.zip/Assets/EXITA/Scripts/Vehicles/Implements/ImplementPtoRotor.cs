using UnityEngine;

namespace ExitaUtara
{
    /// <summary>
    /// Optional component for a rotavator shaft/rotor or another PTO-driven part.
    /// Put it on the rotating mesh or its pivot object.
    /// </summary>
    public class ImplementPtoRotor : MonoBehaviour
    {
        [SerializeField] private Vector3 localAxis = Vector3.forward;
        [SerializeField, Min(0f)] private float rotationsPerMinute = 540f;
        [SerializeField] private bool reverseDirection;
        private bool running;

        public void SetRunning(bool value) => running = value;

        private void Update()
        {
            if (!running || rotationsPerMinute <= 0f) return;

            float direction = reverseDirection ? -1f : 1f;
            float degrees = direction * rotationsPerMinute * 6f * Time.deltaTime;
            transform.Rotate(localAxis.normalized, degrees, Space.Self);
        }
    }
}
