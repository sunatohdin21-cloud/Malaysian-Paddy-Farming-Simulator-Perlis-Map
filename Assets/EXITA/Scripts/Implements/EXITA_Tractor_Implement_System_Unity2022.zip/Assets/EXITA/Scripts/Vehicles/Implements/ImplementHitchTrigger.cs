using UnityEngine;

namespace ExitaUtara
{
    /// <summary>
    /// Put this on a trigger collider near the tractor's rear hitch.
    /// The trigger object must also have a Rigidbody somewhere in its hierarchy.
    /// </summary>
    [RequireComponent(typeof(Collider))]
    public class ImplementHitchTrigger : MonoBehaviour
    {
        [SerializeField] private TractorImplementSystem tractorSystem;

        private void Reset()
        {
            Collider trigger = GetComponent<Collider>();
            trigger.isTrigger = true;
            if (tractorSystem == null)
                tractorSystem = GetComponentInParent<TractorImplementSystem>();
        }

        private void OnTriggerEnter(Collider other)
        {
            if (tractorSystem == null) return;
            FarmImplement implement = other.GetComponentInParent<FarmImplement>();
            if (implement != null)
                tractorSystem.SetNearbyImplement(implement);
        }

        private void OnTriggerExit(Collider other)
        {
            if (tractorSystem == null) return;
            FarmImplement implement = other.GetComponentInParent<FarmImplement>();
            if (implement != null && tractorSystem.AttachedImplement != implement)
                tractorSystem.SetNearbyImplement(null);
        }
    }
}
