# Sistem Sambungan Peralatan Traktor — EXITA UTARA

Sasaran: Unity 2022.3.62f1, namespace `ExitaUtara`.

## Fail dan lokasi
Salin empat fail C# ke:
`Assets/EXITA/Scripts/Vehicles/Implements/`

- `FarmImplement.cs` — konfigurasi setiap implement, lift dan status PTO.
- `ImplementPtoRotor.cs` — putaran visual shaft/rotor apabila PTO hidup.
- `TractorImplementSystem.cs` — pasang, tanggal, angkat/turunkan dan PTO.
- `ImplementHitchTrigger.cs` — mengesan implement berhampiran hitch.

## Persediaan model traktor (Ford 366 dan Ford 5000)
1. Tambah `TractorImplementSystem` pada root GameObject traktor.
2. Buat empty GameObject `HitchPoint` di belakang traktor pada kedudukan sambungan.
3. Buat empty GameObject `ImplementParent` (boleh sama dengan root traktor).
4. Buat empty GameObjects `LeftLowerLink`, `RightLowerLink` dan `TopLink` pada lokasi pautan tiga titik.
5. Seret semua Transform tersebut ke medan yang sepadan dalam Inspector.
6. Tambah child GameObject `HitchTrigger` dengan BoxCollider, tandakan `Is Trigger`.
7. Tambah `ImplementHitchTrigger` pada `HitchTrigger`, kemudian isi `Tractor System`.
8. Pastikan ada Rigidbody pada traktor atau objek trigger mengikut setup fizik projek. Jika Rigidbody pada root, gunakan `isKinematic` jika traktor dikawal skrip.

## Persediaan setiap implement
1. Letakkan model GLB dalam prefab GameObject.
2. Tambah `FarmImplement` pada root prefab.
3. Buat child empty `AttachPoint` pada lokasi pin hitch implement; isi medan `Attach Point`.
4. Set `Implement Type` ikut peralatan.
5. Tandakan `Requires Pto` untuk rotavator, puddler berputar atau alat yang benar-benar menggunakan PTO.
6. Jika perlu gerakan angkat, buat pivot child dan isi `Lift Pivot`; laraskan `Lowered Local Euler` dan `Raised Local Euler`.
7. Untuk shaft/rotor, tambah `ImplementPtoRotor` pada mesh/pivot yang hendak berputar. Laraskan `Local Axis` dan RPM.

## Butang UI Android
Cipta Button dalam Canvas dan sambungkan OnClick kepada `TractorImplementSystem`:
- Pasang: `UI_Attach`
- Tanggal: `UI_Detach`
- PTO: `UI_TogglePto`
- Angkat/Turun: `UI_RaiseLower`

`UI_Attach` hanya berjaya jika implement dikesan oleh trigger, belum ada implement dipasang, dan jaraknya tidak melebihi `Attach Distance`.

## Nota penting
- Kod ini ialah asas integrasi. Belum diuji dalam Unity Editor atau pada model sebenar.
- GLB yang telah dimuat naik ialah mesh asas; titik attach dan pivot mesti disusun dalam prefab Unity.
- Putaran PTO ialah animasi visual ringkas, bukan simulasi mekanikal.
- Uji skala model, orientasi paksi, collider, Rigidbody, parent transform, dan kedudukan hitch.
- Untuk implement yang bukan PTO, butang PTO tidak akan menghidupkannya.
